using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    [Header("Animations")] 
    [SerializeField] private KeyCode Alpha1; 
    [SerializeField] private KeyCode Alpha2;
    [SerializeField] private KeyCode Alpha3;
    private Animator _animator;
    private Wizard _wizard;
    [Header(("Teleport"))]
    [SerializeField] private float _distanciaX;
    [SerializeField] private float _distanciaY;
    private float horizontalInput;
   
    // Start is called before the first frame update
    void Start()
    {
        _animator = GetComponent<Animator>();
        _wizard = GetComponent<Wizard>();
    }

    // Update is called once per frame
    void Update()
    {
        horizontalInput = Input.GetAxis("Horizontal");
        
        if (horizontalInput > 0.01f)
            transform.localScale = Vector3.one;
        else if (horizontalInput < -0.01f)
            transform.localScale = new Vector3(-1, 1, 1);

        if (Input.GetKeyDown(Alpha1))
        {
            _animator.SetTrigger("isHurt");
            _wizard.TakeDamage(1f);
        }
        if (Input.GetKeyDown(Alpha2))
        {
            _animator.SetTrigger("isDead");
        }
        if (Input.GetKeyDown(Alpha3))
        {
            _animator.SetTrigger("isAttacking");
        }
    }

    public void teleportPlayer()
    {
        Vector3 newPos = new Vector3(transform.position.x + _distanciaX, transform.position.y + _distanciaY, transform.position.z);

        transform.position = newPos;
    }
    
    private void OnDrawGizmos()
    {
        // Dibuja una línea entre el jugador y la posición marcada por las variables distanciaY y distanciaX
        Gizmos.color = Color.red;
        Gizmos.DrawLine(transform.position, new Vector3(transform.position.x + _distanciaX, transform.position.y + _distanciaY, transform.position.z));
    }
}
